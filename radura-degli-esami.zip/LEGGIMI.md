# Radura degli Esami — app installabile

App web (PWA) che funziona offline e si sincronizza tra iPhone, iPad e Mac con un codice segreto.

## Pubblicarla gratis su GitHub Pages (5 minuti, una volta sola)
1. Su github.com crea un nuovo repository pubblico, per esempio `radura-degli-esami`.
2. Nel repository: **Add file → Upload files**, trascina **tutto il contenuto** di questa cartella (index.html, sw.js, manifest.webmanifest e le cartelle css, js, assets, icons) e premi **Commit changes**.
3. Vai in **Settings → Pages**: in "Branch" scegli `main` e cartella `/ (root)`, poi **Save**.
4. Dopo un minuto l'app è online su `https://TUO-NOME.github.io/radura-degli-esami/`.

## Installarla
- **iPhone / iPad**: apri l'indirizzo in Safari → tasto Condividi → «Aggiungi alla schermata Home».
- **Mac**: Safari → menu File → «Aggiungi al Dock» (in Chrome: icona di installazione nella barra degli indirizzi).

## Stessi dati su tutti i dispositivi
1. Sul primo dispositivo scegli «Inizia una nuova avventura»: ricevi un **codice della radura** (lo ritrovi in Zaino → Dispositivi).
2. Sugli altri dispositivi apri l'app installata, scegli «Ho già un codice» e inseriscilo.
Il codice è come una password: chi lo conosce vede i tuoi dati.

## Aggiornamenti
Quando ricevi una nuova versione, ricarica i file nel repository (Upload files sovrascrive): l'app si aggiorna da sola alla riapertura.

Crediti grafica personaggi: Liberated Pixel Cup / Universal LPC Spritesheet Character Generator (CC-BY-SA 3.0, GPL 3.0, OGA-BY 3.0) — elenco completo in assets/credits.json.
